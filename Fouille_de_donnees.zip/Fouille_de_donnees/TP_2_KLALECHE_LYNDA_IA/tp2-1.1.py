
# !/usr/bin/env python
# -*- coding: utf-8 -*-
from itertools import count

import pandas as pd
from _R_square_clustering import r_square

# read input text and put data inside a data frame
covid19 = pd.read_csv('covid19.csv', parse_dates=[7, 8], encoding="ISO-8859-1")
print(covid19.head())
print(covid19.shape)
print(covid19.describe(include='all'))
print(covid19.dtypes)
features=covid19.columns


#--------------compute number on missing value in the dataframe---------------------------#
print("#--------------compute number on missing value in the dataframe--------------------#")
print(covid19.isnull().sum())
print(covid19.isin(['', None]).sum())


#-----------------calculez le nombre de doses pour 1 000 habitants------------------------#
print("")
print("#-----------------calculez le nombre de doses pour 1 000 habitants-----------------#")
column_names = ['vaccine_2021-winter', 'vaccine_2021-spring', 'vaccine_2021-summer', 'vaccine_2021-fall',
                'vaccine_2022-winter']
covid19['total_vaccines'] = covid19[column_names].sum(axis=1)
nb_dose_1000 = covid19['total_vaccines'] * 1000 / covid19['population']

##--------------------------suppression de la variable 'population'------------------------#
covid19 = covid19.drop('population', 1)


#----------------------------#ajout de la variable nb_dose_1000----------------------------#
print('#-----------------ajout de la variable nb_dose_1000---------------------------------#')
covid19.insert(2, "nb_dose_1000", nb_dose_1000, True)
#print(covid19.columns)


#---------------------------------------------#4 ACP---------------------------------------#
print('#---------------------------------------#4 ACP--------------------------------------#')
#----------------------# 4.1 Standardisation des donnees-------------------------------------#


from sklearn.preprocessing import StandardScaler

X = covid19.loc[:, ~covid19.columns.isin(['country', 'country_code'])]

sc = StandardScaler()
X_std = sc.fit_transform(X)

import numpy as np
print('')
print('mean')
print(np.mean(X_std, axis=0))
print('')
print('std')
print(np.std(X_std, axis=0, ddof=0))

#----------------------# 4.2 ACP-------------------------------------#

print("ACP et selection de variables")
from sklearn.decomposition import PCA

acp = PCA()
coord = acp.fit_transform(X_std)

 # nb of computed components
print('le nombre de composantes principales calculées',acp.n_components_)

 # plot eigen values
n = np.size(X_std, 0)
p = np.size(X_std, 1)
eigval = float(n-1)/n*acp.explained_variance_

print("Les valeurs propres de l'ACP: ")
print(eigval)

#-----------------plot instances on the first plan (first 2 factors)--------------------------#

import matplotlib.pyplot as plt

y = covid19['country_code']
n = np.size(X_std, 0)
p = np.size(X_std, 1)

fig, axes = plt.subplots(figsize=(12, 12))

for i in range(n):
    plt.annotate(y.values[i], (coord[i, 0], coord[i, 1]))

plt.plot([-7, 7], [0, 0], color='silver', linestyle='-', linewidth=1)
plt.plot([0, 0], [-7, 7], color='silver', linestyle='-', linewidth=1)
plt.savefig('fig/acp_instances_1st_plan')
plt.close(fig)

# ------------------plot instances on third and fourth factor-----------------#
for i in range(n):
    plt.annotate(y.values[i], (coord[i, 2], coord[i, 3]))


plt.plot([-7, 7], [0, 0], color='silver', linestyle='-', linewidth=1)
plt.plot([0, 0], [-7, 7], color='silver', linestyle='-', linewidth=1)
plt.savefig('fig/acp_instances_2nd_plan')
plt.close(fig)

#-------------------------- 5 explained variance scores--------------------------#
#pourcentage de variance expliquee
print("Pourcentage de variance expliquee: ")
print(acp.explained_variance_ratio_)

# on remarque que les 4 premiers facteurs expliquent 75,34% de l'inertie totale (de l'information)
# (avec 75,34 = somme des 4 premiers nombres du print juste au dessus)

# # Correlations entre les facteurs et les variables originales
sqrt_eigval = np.sqrt(eigval)
corvar = np.zeros((p,p))
for k in range(p):
     corvar[:,k] = acp.components_[k,:] * sqrt_eigval[k]

def correlation_circle(var_names,nb_var,x_axis,y_axis):
    fig, axes = plt.subplots(figsize=(8,8))
    minx = -1
    maxx = 1
    miny = -1
    maxy = 1
    axes.set_xlim(minx,maxx)
    axes.set_ylim(miny,maxy)
    # label with variable names
    # ignore first two variables (instance name and code)
    for j in range(nb_var):
        plt.annotate(var_names[j+2],(corvar[j,x_axis],corvar[j,y_axis]))
        axes.arrow(0, 0, corvar[j,x_axis],corvar[j,y_axis], head_width=0.01, head_length=0.02, fc='k', ec='k')
    # axes
    plt.plot([minx,maxx],[0,0],color='silver',linestyle='-',linewidth=1)
    plt.plot([0,0],[miny,maxy],color='silver',linestyle='-',linewidth=1)
    # add a circle
    cercle = plt.Circle((0,0),1,color='blue',fill=False)
    axes.add_artist(cercle)
    plt.savefig('fig/acp_correlation_circle_axes_'+str(x_axis)+'_'+str(y_axis))
    plt.close(fig)



correlation_circle(covid19.columns, p, 0, 1)
correlation_circle(covid19.columns, p, 2, 3)

#--------------------------------------------------------------------------------------------------------#
# -----------------------------------K-means-------------------------------------------------------------#
## normalisation des donnees
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
X_norm = scaler.fit_transform(X)

## k-means
from sklearn.cluster import KMeans

# # Plot elbow graphs for KMeans using R square
print("--------k-means et R2----------")
lst_k = range(2, 21)
lst_rsq = []
for k in lst_k:
    est = KMeans(n_clusters=k)
    est.fit(X_norm)
    lst_rsq.append(r_square(X_norm, est.cluster_centers_, est.labels_, k))
    print("Nombre de cluster consideres: ", k)
    print("R2: ", r_square(X_norm, est.cluster_centers_, est.labels_, k))
    print("------------------------------------")

fig = plt.figure()
plt.plot(lst_k, lst_rsq, 'bx-')
plt.xlabel('k')
plt.ylabel('R2')
plt.title('R2 en fonction du nombre des clusters k')
plt.savefig('fig/R2_methode_des_k-means')
plt.close()

#d'apres la courbe de l'evolution du R2 en fonction du nombre des clusters on remaque que l'evolution du R2
#n'est plus significative a partir de k=8.

#k=8
est = KMeans(n_clusters=8)
est.fit(X_norm)
labels=est.labels_
covid19['kmeans_labels']=labels

for cl in [labels[9],labels[6],labels[2]]:
    df = covid19[covid19.kmeans_labels==cl].copy()
    print(df['country'])

# le groupe de la France : France, Germany, Italy, Spain
# groupe de Denmark : Austria, Cyprus, Denmark, Greece
# groupe de Bulgaria : Bulgaria, Croatia, Hungry, Poland, Slovakia
# On remarque que ces groupes sont geographiquement voisins et constituent selon cette methode de classification
# des clusters ensemble. La maladie du covid19 agit de la meme maniere sur les pays qui sont voisins

# # clustering hierarchique
from scipy.cluster.hierarchy import dendrogram, linkage

lst_labels = list(map(lambda pair: pair[0]+str(pair[1]), covid19['country']))
linkage_matrix = linkage(X_norm, 'ward')
fig = plt.figure()
dendrogram(linkage_matrix, color_threshold=0, labels=lst_labels)
plt.title('Hierarchical Clustering Dendrogram (Ward)')
plt.xlabel('sample index')
plt.ylabel('distance')
plt.tight_layout()
plt.savefig('fig/hierarchical-clustering')
plt.close()

# # on remarque du graphique du dendograme que les pays qui sont voisins geographiquement ont tendance a se regrouper
# dans le meme cluster, ceci revient a des caracterisques communes partagees par ces pays : climatiques, ethniques,
# medicales, economiques

# # on affiche les 15 dernieres distances entre clusters
print(linkage_matrix[-15:, 2])
# on obtient :
#[1.1299471  1.17295084 1.22927812 1.3666897  1.44541428 1.45217711
# 1.47874372 1.48072886 1.50197282 1.67040931 2.00540257 2.09081578
# 2.83757131 3.9286821  4.70311651]

#on remarque un saut de la valeur de la distance entre les groupes a partir du 5eme et 6eme fusions des
#clusters, une coupure a ces niveaux va creer 5 (ou 6) clusters

