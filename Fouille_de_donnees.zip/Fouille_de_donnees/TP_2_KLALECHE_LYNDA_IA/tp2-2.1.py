#!/usr/bin/env python
# -*- coding: utf-8 -*-
import csv

import numpy as np
import pandas as pd
from matplotlib import pyplot
from sklearn.dummy import DummyClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn import tree
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn import svm
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import cross_val_predict
from sklearn import metrics
from sklearn.impute import SimpleImputer

#-------------------------------------------Classement---------------------------------------------------#



dummycl = DummyClassifier(strategy="most_frequent")
gmb = GaussianNB()
dectree = tree.DecisionTreeClassifier()
rdforest = RandomForestClassifier()
logreg = LogisticRegression(solver="liblinear")
svc = svm.SVC(gamma='scale')

lst_classif = [dummycl, gmb, dectree, rdforest, logreg, svc]
lst_classif_names = ['Dummy', 'Naive Bayes', 'Decision tree', 'Random Forest', 'Logistic regression', 'SVM']

def accuracy_score(lst_classif,lst_classif_names,X,y):
    for clf,name_clf in zip(lst_classif,lst_classif_names):
        scores = cross_val_score(clf, X, y, cv=5)
        print("Accuracy of "+name_clf+" classifier on cross-validation: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))

def confusion_matrix2(lst_classif,lst_classif_names,X,y):
    for clf,name_clf in zip(lst_classif,lst_classif_names):
        predicted = cross_val_predict(clf, X, y, cv=5) 
        print("Accuracy of "+name_clf+" classifier on cross-validation: %0.2f" % metrics.accuracy_score(y, predicted))
        print(metrics.confusion_matrix(y, predicted))





# read input text and put data inside a dataframe

#f = open("labor/labor.txt", "r")
#print(f.read())


na_val={'?','none'}
labor = pd.read_csv('labor/labor.csv', parse_dates=[7, 8], encoding = "ISO-8859-1",na_values=na_val)
print(labor.shape)
print(labor.columns)
print(labor['class'].value_counts())


print("****************Affichage de la base de données**************")
print(labor.head())
Features=labor.columns
for att in Features:
    print("")
    print("****************Description de l'attributs", att, "**************")
    print(labor[att].unique())
    print(labor[att].describe(datetime_is_numeric=True))


    print("---------------------------------------------------------------------")

#--------------compute number on missing value in the dataframe-------------------#
print("compute number on missing value in the dataframe")
print(labor.isin(['?']).sum())
print(labor.isin(['', None]).sum())

print()

#------------------------------Type of variables---------------------------------#
print("#--------------Type of variables-------------------#")
print(labor.dtypes)

#---------------------------Replace missing values by mean and scale numeric values---------------------#
labor['standby-pay'] = pd.to_numeric(labor['standby-pay'],errors = 'coerce')
labor['shift-differential'] = pd.to_numeric(labor['shift-differential'],errors = 'coerce')
data_num = labor.select_dtypes(include='float64')#select numerical var

imputer = SimpleImputer(missing_values = np.nan,strategy='mean')
imputer = imputer.fit(data_num)
data_num=imputer.transform(data_num)
print(imputer.transform(data_num))
print('------------------------------------------------------')

#standardisation des données
from sklearn.preprocessing import StandardScaler, LabelEncoder

scaler = StandardScaler()
data_num_scaled = scaler.fit_transform(data_num)
print(data_num_scaled)

#########################################################################
# 4 - Classement

lst_classif = [dummycl, gmb, dectree, rdforest, logreg, svc]
lst_classif_names = ['Dummy', 'Naive Bayes', 'Decision tree', 'Random Forest', 'Logistic regression', 'SVM']



# # Create Training and Test Sets and Apply Scaling
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix

X = data_num_scaled
y = labor['class']
X_train, X_test, y_train, y_test = train_test_split(X, y,test_size=0.33, random_state=0)
labels = np.unique(y_test)

for clf,name_clf in zip(lst_classif,lst_classif_names):
     clf.fit(X_train, y_train)
     # TODO
     y_pred = clf.predict(X_test)

     print('Accuracy of '+name_clf+' classifier on training set: {:.2f}'  .format(clf.score(X_train, y_train)))
     print('Accuracy of '+name_clf+' classifier on test set: {:.2f}' .format(clf.score(X_test, y_test)))
     print(confusion_matrix(y_true=y_test, y_pred=y_pred, labels=['bad','good']))


#############################################################################################
#--6----------------------------------------------------------------------------------------#
# Replace missing values by mean and discretize categorical values
data_cat = labor.select_dtypes(exclude='float64').drop('class',axis=1)


imputer = SimpleImputer(missing_values = np.nan,strategy='most_frequent')
imputer = imputer.fit(data_cat)
data_cat=imputer.transform(data_cat)
print(imputer.transform(data_cat))

# ---------------------Disjonction with OneHotEncoder-----------------------------
print("# ---------------------Disjonction with OneHotEncoder-----------------------------")
from sklearn.preprocessing import OneHotEncoder

from sklearn.compose import ColumnTransformer

encoder = OneHotEncoder(sparse=False)
data_cat_encoded = encoder.fit_transform(data_cat)

#y_array = y.to_numpy()
#y_array = y_array.reshape(-1,1)
#y_encoded = encoder.fit_transform(y_array)
#print(y_encoded)

#-----application des algorithmes------#

X_cat = data_cat_encoded
y_cat = y
X_cat_train, X_cat_test, y_cat_train, y_cat_test = train_test_split(X_cat, y_cat,test_size=0.33, random_state=0)

for clf,name_clf in zip(lst_classif,lst_classif_names):
     clf.fit(X_cat_train, y_cat_train)
     # TODO
     y_cat_pred = clf.predict(X_cat_test)

     print('Accuracy of '+name_clf+' classifier on training set: {:.2f}'  .format(clf.score(X_cat_train, y_cat_train)))
     print('Accuracy of '+name_clf+' classifier on test set: {:.2f}' .format(clf.score(X_cat_test, y_cat_test)))
     print(confusion_matrix(y_true=y_cat_test, y_pred=y_cat_pred, labels=['bad','good']))
     #print("y_test: ", y_cat_test)
     #print("y_pred: ",y_cat_pred)





#############################################################################################
#--7----------------------------------------------------------------------------------------#

cl_cat = encoder.get_feature_names(['cost-of-living-adjustment', 'pension', 'education-allowance',
       'vacation', 'longterm-disability-assistance',
       'contribution-to-dental-plan', 'bereavement-assistance',
       'contribution-to-health-plan'])

cl_num = ['duration', 'wage-increase-first-year', 'wage-increase-second-year',
       'wage-increase-third-year', 'working-hours', 'standby-pay',
       'shift-differential', 'statutory-holidays']


cat_encoded_frame =  pd.DataFrame(data_cat_encoded, columns= cl_cat)
num_encoded_frame =  pd.DataFrame(data_num_scaled, columns= cl_num)

Z = pd.concat([cat_encoded_frame, num_encoded_frame], axis=1)

Z_train, Z_test, y_train, y_test = train_test_split(Z, y,test_size=0.33, random_state=0)

for clf,name_clf in zip(lst_classif,lst_classif_names):
     clf.fit(Z_train, y_train)
     # TODO

     y2_pred = clf.predict(Z_test)
     
     print('Accuracy of '+name_clf+' classifier on test set: {:.2f}' .format(clf.score(Z_test, y_test)))
     print(confusion_matrix(y_true=y_test, y_pred=y2_pred))



