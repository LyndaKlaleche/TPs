#!/usr/bin/env python
# -*- coding: utf-8 -*-

from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import association_rules
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import numpy as np


#----------------------------------------------------------------------------------------------#
#----------------------Regle d'association-----------------------------------------------------#
print("#----------------------Regle d'association-----------------------------------------------------#")

from scipy.io import arff
df= arff.loadarff('supermarket.arff')
supermarket = pd.DataFrame(df[0])
print("")
print ("------------------------------La liste des attributs--------------------------")
print(supermarket.columns.tolist())
#Les attributs sont de type CATEGORIELLE nominal
#{t} indicates that the product or departement were a part of this transaction
#'?' denotes that particular item wasnt a part of this  transaction
print("")
print ("------------------------------La base--------------------------")
print(supermarket)
print("")
print ("------------------------------# convert categorical values into one-hot vectors and ignore ? values --------------------------")

#There are three common approaches for converting ordinal and categorical variables to numerical values. They are:
#Ordinal Encoding
#One-Hot Encoding
#Dummy Variable Encoding


from sklearn.preprocessing import OneHotEncoder
from numpy import asarray
from sklearn.preprocessing import LabelEncoder
# convert categorical values into one-hot vectors and ignore ? values
# corresponding to missing values
supermarket_one_hot = pd.get_dummies(supermarket)
supermarket_one_hot.drop(supermarket_one_hot.filter(regex='_b\'\?\'$',axis=1).columns,axis=1,inplace=True)
print(supermarket_one_hot)


#"run apriori algo"
#Get frequent itemsets from a one-hot DataFrame
print("")
print ("------------------------------# List of frequent itemsets --------------------------")

frequent_itemsets = apriori(supermarket_one_hot, min_support=0.1, use_colnames=True)
pd.set_option('display.max_colwidth',None)
print("**************************liste des frequents_itemsets**************************")
print(frequent_itemsets)

#Get rules
print("")
print ("------------------------------# List rules--------------------------")

from mlxtend.frequent_patterns import association_rules
rules = association_rules(frequent_itemsets,metric="confidence",min_threshold=0.7)
print(rules[['antecedents','consequents','support','confidence']].head())
print(rules.shape)
print(rules.columns)

print("")
print ("------------------------------select rules with 5 Items--------------------------")

#compute the antecedent and consequent length
rules['length_antecedent'] = rules['antecedents'].apply(lambda x: len(x))
rules['length_consequents'] = rules['consequents'].apply(lambda x: len(x))
# select rules with 5 Items
rules_five_items = rules[(rules['length_antecedent'] == 4) &   rules['length_consequents']==1]

print(rules_five_items[["antecedents","consequents","confidence"]])

print("")
print ("------------------------------select best rule for lift metric--------------------------")
best_rules_lift=rules[rules['lift']==rules['lift'].max()]
print(best_rules_lift[["antecedents","consequents"]])
# Un « lift » supérieur à 1 traduit une corrélation positive de X et Y

print("")
print ("------------------------------# # select best rule for confidence metric--------------------------")
best_rules_confidence=rules[rules['confidence']==rules['confidence'].max()]
print(best_rules_confidence[["antecedents","consequents"]])

print("")
print ("------------------------------# # product associating with cofee and biscuits--------------------------")
res=rules.loc[rules['antecedents'] == {'coffee_b\'t\'',  'biscuits_b\'t\''}]#uniquement dans la partie antecedents
print(res[["antecedents","consequents","support","confidence"]])

